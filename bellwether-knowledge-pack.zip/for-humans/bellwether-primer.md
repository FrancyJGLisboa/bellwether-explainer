## 1. What is bellwether

Bellwether is a Python archive-and-server for US and global agricultural intelligence, served over MCP. It ingests 12 as-published sources — USDA WASDE, PSD, ESR, GATS, GAIN attaché reports, NASS crop statistics, FGIS grain inspections, FSA certified acreage, CFTC Commitments of Traders (COT) positioning, CPC ENSO, NOAA teleconnection indices (AO/NAO/PNA/PDO/DMI), and NDMC US Drought Monitor — since 2020, with NASS, ENSO, and USDM reaching back to 2000. The codebase itself is indexed into a 384-dim knowledge base of 246 passages across 4 components, with 13 CLI entrypoint commands.

## 2. What can it do for you

- Answer the fundamentals + positioning + weather legs of an ag market question, with every number cited to a `source_file` + `release_date` — never eyeballed.
- Compute direction/magnitude of change via `interpret_change` rather than relying on LLM guesswork.
- Gate answers deterministically through `ground_answer`, which can also run a structural lint (tagged assumptions, assumption-count ≤ served-fact-count, terminal call bound to a real ledger id).
- Record falsifiable market calls in a prediction ledger (`eval/predictions.jsonl`) via the `predict` MCP tool, later auto-resolved (house-vs-official, hit/miss) and digested by a watch daemon.
- Run a mechanical, no-lookahead backtest — a 72-item grid of WASDE ending-stocks calls for Corn/Soybeans/Wheat over 2023-07 to 2025-06 — to build a track record without human judgment in the loop.
- Refuse out-of-corpus questions by name (price/basis, term structure, trade consensus surveys, daily flash sales, NASS county detail, weather forecasts) instead of improvising an answer.

## 3. What is it made of (the components)

Four Python components, `tests` and `eval` both depending on `bellwether`:

- **bellwether** — the core package: CLI, the facts/indexing layer, `predict.py` (prediction ledger logic), `watch.py` (reindex + score daemon), `serve.py` (MCP serving and `ground_answer`), `interpret.py` (change interpretation / structural lint).
- **tests** — the pytest suite (offline fixtures for predict/ground/serve/watch); a recorded baseline of 112 passing tests, with goal specs targeting growth to ≥116.
- **eval** — the evaluation harness: `backtest_grid.py` (deterministic grid generator), `backtest.py` (runner), `heldout_eval.py` (held-out checks such as ENSO ONI season ordering), and the live `predictions.jsonl` ledger.
- **scripts** — operational scripts, e.g. `outlook_run.sh` (a roster runner with a `--smoke` mode).

External dependencies: `claimcheck`, `pypdf`, `xlrd` — consistent with parsing PDF and Excel source documents plus verifying claims against them. The package exposes 0 public symbols — it's built as an application + MCP server, not a library meant to be imported elsewhere.

## 4. How it works

Sources are reindexed into a local `archive/facts.db` (recorded at roughly 10.4M rows) that keeps every release vintage rather than overwriting history. Vintage behavior differs by series: NASS annual values and ENSO ONI are the *current* source vintage (revised in place on re-fetch), while NASS weekly condition, COT positions, ENSO narratives, and USDM drought categories never revise once published.

The MCP server enforces an answering discipline: cite every figure to `source_file`+`release_date`; treat price/basis/term-structure as fully out of scope (the archive holds no futures or cash prices — that's deferred to sibling tools like commodity-pulse or safra-brief); and never present regime/crowding/trend classification as something the archive itself states — that's downstream analysis layered on top of raw data.

Predictions use a canonical house-vs-official record — `{id, asked_at, question, source, commodity_code, country, market_year, field, unit, release_date, house, official, confidence}` (confidence is a float in (0,1)) — with two hard rules: a call must be discriminating (a base rate above 75% means the threshold can't be wrong — pick a call that can be), and only one call is allowed per series per release. A watch daemon reindexes the archive, then runs `score_ledger` to resolve pending predictions and send a hit/miss digest.

The `bellwether-outlook` skill is the intended human workflow: check `status` for freshness first (disclose or refuse if stale/out-of-corpus), scope which of the 12 sources the question actually needs, pull cited facts, compute moves via `interpret_change`, decompose reasoning into fact + named assumption, and end on a headline call tied to a real ledger prediction. It's meant to run on Opus or Sonnet — a held-out eval found Sonnet drops temporal-ordering items (ENSO season recall) while Opus stayed clean; Haiku is explicitly not a supported serving model for this archive, though the server can't enforce that itself.

## 5. How do I install and use it

```
uv sync
```

Build the archive:

```
uv run bellwether all --since 2020 --root archive
uv run bellwether facts && uv run bellwether fts
```

Check state / maintain it:

```
uv run bellwether status
uv run bellwether refresh
```

Pull individual sources (NASS and USDM reach back to 2000; the rest since 2020):

```
uv run bellwether wasde --since 2020
uv run bellwether wasde cot
uv run bellwether esr psd --since 2020
uv run bellwether gats --since 2020
uv run bellwether gain --since 2020
uv run bellwether nass --since 2000
uv run bellwether usdm --since 2000
```

Once indexed, query it through the MCP tools (`status`, `query_facts`, `interpret_change`, `ground_answer`, `predict`, `search_reports`, `list_reports`, `get_report`) — normally driven via the `bellwether-outlook` skill rather than called by hand. Run tests with `uv run pytest -q`.

## 6. Honest scope and limits

- **No price data at all.** No futures, cash, basis, or term structure — bellwether refuses these questions rather than approximating; use a separate tool (commodity-pulse / safra-brief) for the price leg.
- **Out-of-corpus by design**, not by oversight: trade consensus surveys, daily flash sales, NASS county-level detail, and weather forecasts are refused, not guessed.
- **Not a library.** 0 public symbols — this is an application + archive + MCP server, built to be run and queried, not imported.
- **Model-tier dependent.** The answering discipline is validated on Sonnet/Opus only; Haiku degrades on boundary-refusal and cross-source temporal recall and isn't a supported serving model — but the server has no way to enforce which model the caller uses.
- **Vintage nuance.** Some series revise in place (NASS annual, ENSO ONI current vintage) while others are frozen at first publication (NASS weekly condition, COT, ENSO narratives, USDM) — worth knowing before treating any "current" number as final.
- **Actively in-progress.** The repo carries explicit goal specs (`.scratch/phase1-close-the-loop`, `.scratch/phase2-lint-vintage-enso`) with binary success checks — daemon-scored predictions, the 72-item backtest, and the ENSO ordering fix were tracked as phase deliverables, not necessarily a static finished feature set. Run `uv run bellwether status` and the test suite to see what's actually live rather than assuming everything above is current.
