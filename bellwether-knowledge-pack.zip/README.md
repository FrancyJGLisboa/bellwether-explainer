# bellwether Drop-in

One zip. Two halves: a for-humans primer and a for-ai searchable knowledge base.

## What's inside

```
bellwether-dropin/
  for-humans/   — read first
    bellwether-primer.md         — top-down orientation: what it is, why, how it works
  for-ai/       — the searchable knowledge pack (wire this into your agent)
    bellwether-kb.rvf            — single 384-dim bge-small vector DB (the "brain")
    bellwether-kb.passages.jsonl — full passage text (333 passages; search returns TEXT, not {id,distance})
    bellwether-kb.ids.json       — id → passage index
    bellwether-symbols.json      — exact public API: every symbol + signature + doc + location
    bellwether-dep-graph.json    — component dependency graph (what depends on what)
    bellwether-entrypoints.json  — build/test/run/install commands + binaries
    ask-kb.mjs · kb-mcp-server.mjs · kb.config.mjs · resolve-deps.mjs · package.json
  README.md     — this file
  manifest.json — build metadata
```

## Studio (NotebookLM)
This is a **studio-less** build (INV-03): the searchable AI pack ships now; NotebookLM audio/report
media follow up later if produced. Nothing here depends on them.

## Three steps to wire the AI half in
```bash
# 1 — unzip + install (two deps, Node 18+)
unzip bellwether-knowledge-pack.zip && cd bellwether-dropin/for-ai && npm install

# 2 — ask the brain a question straight away
node ask-kb.mjs bellwether "what does bellwether actually do"

# 3 — point your AI host at it with a .mcp.json in your project root:
#   { "mcpServers": { "bellwether-kb": { "command": "node", "args": ["for-ai/kb-mcp-server.mjs"] } } }
```

Built with the Repo-Primer recipe (ADR-0001 / ADR-0005). Embedder: Xenova/bge-small-en-v1.5.
